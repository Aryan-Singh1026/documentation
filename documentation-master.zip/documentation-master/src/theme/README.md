# Theme customization

This folder contains theme components overriding

> **NOTE:** Use only for critical cases!

## See also

- [https://docusaurus.io/docs/using-themes#wrapper-your-site-with-root](https://docusaurus.io/docs/using-themes#wrapper-your-site-with-root)
- [https://docusaurus.io/docs/using-themes#theme-components](https://docusaurus.io/docs/using-themes#theme-components)
