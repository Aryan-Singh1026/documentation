import "@fontsource-variable/overpass";

export { default } from "./_home";
